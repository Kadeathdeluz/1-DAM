package projectebase;

import java.util.ArrayList;

/**
 *
 * @author Roldán Sanchis Martínez
 */
public interface RomeuIJulieta {
    
    public void estimar(ArrayList<Ciutada> ciutadans, Ciutada estimat);
}

package projectebase;

public enum Vulnerable {
    Vampir, Llop, Huma, Tots
}

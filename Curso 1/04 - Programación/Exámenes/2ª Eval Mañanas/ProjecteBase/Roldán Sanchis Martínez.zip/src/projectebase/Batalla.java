package projectebase;

public interface Batalla {

    int FORCA_MIN = 25;
    int VITALITAT_MIN = 50;

    public Ciutada combat(Ciutada oponent);
}
